package com.example.practicaltest.data.model

data class MovieModel(
    var page: Page
)