package com.example.practicaltest.ui.movie_list

interface MovieListNavigator {
    fun onCancelClicked()
    fun onSearchClicked()
    fun onBackClicked()
    fun onSearchHeaderClicked()
}